#include <stdio.h>
void main()
{
	int i;
	clrscr();
	for (i = 0; i <= 5; i++)
	{
		printf("\n %d \n", i);
	}
	getch();
}