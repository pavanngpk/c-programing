#include<stdio.h>
void main()
{
	int a=7,b=6,c=10;
	clrscr();
	printf("\na>b&&a<c:%d",((a>b)&&(a<c));
	getch();
}