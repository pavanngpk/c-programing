#include<stdio.h>
void main()
{
	int a=5,b=3;
	int addition,subtraction;
	int division, multiplication;
	int modulus,increment,decrement;
	clrscr();
	addition=a+b;
	subtraction=a-b;
	division=a/b;
	multiplication=a*b;
	modulus=a%b;
	increment=a++;
	decrement=a--;
	printf("\n a%%b=%d,a%b);
	getch();
	
}