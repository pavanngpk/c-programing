#include <stdio.h>
#include <limits.h>
int main() 
{
	clrscr();
	printf("Maximum Integer Value: %d\n", INT_MAX);
	printf("Minimum Integer Value: %d\n", INT_MIN);
	printf("Maximum Long Value: %ld\n", LONG_MAX);
	printf("Minimum Float Value: %ld\n", LONG_MIN);
	getch();
	return 0;
}