#include<stdio.h>
void main()
{
	float a=5.0,b=2.0, c;
	clrscr();
	c=b/a;
	printf("value of c=%f",c);
	getch();
}