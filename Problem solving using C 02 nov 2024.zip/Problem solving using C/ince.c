#include <stdio.h>
void main()
{
    int x = 10, a;
    a = ++x;
    printf("\nPre-Increment Operation:");
    printf("\na =%d ", a);
    printf("\n x = %d",x);
}