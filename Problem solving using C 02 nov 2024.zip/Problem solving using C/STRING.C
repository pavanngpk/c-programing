#include<stdio.h>
#include<string.h>
void main()
{
	char name[5];
	clrscr();
	printf("\n enter the word \n");
	gets(name);
	printf("\n entered string is \n");
	puts(name);
	getch();
}