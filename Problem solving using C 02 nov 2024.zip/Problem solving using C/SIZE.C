#include<stdio.h>
void main()
{
	clrscr();
	printf("\nsize of short int =%d",sizeof(short int));
	printf("\nsize of int =%d",sizeof(int));
	printf("\nsize of long int =%d",sizeof(long int));
	printf("\nsize of unsigned int =%d",sizeof(unsigned int));
	printf("\nsize of double =%d",sizeof(double));
	getch();
}
