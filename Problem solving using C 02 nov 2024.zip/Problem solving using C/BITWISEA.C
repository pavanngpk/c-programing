#include<stdio.h>
void main()
{
	int a=7,b=2,c,d;
	clrscr();
	c=a&b;
	d=a|b;
	printf("\n min c=a&d:%d",c);
	printf("\n max d=a|b:%d",d);
	getch();
}
